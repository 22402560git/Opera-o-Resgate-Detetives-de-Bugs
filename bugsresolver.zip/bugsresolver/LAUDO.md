# LAUDO TÉCNICO — Operação Resgate: Detetives de Bugs

Projeto: Central de Achados e Perdidos  
Disciplina: Frameworks

> **Observação de configuração:** o ZIP original não contém `lib/firebase_options.dart`. O arquivo é específico do projeto Firebase da escola e não pode ser preenchido com credenciais fictícias. Antes de executar, gere-o com o FlutterFire CLI (`flutterfire configure`) e confirme que o provedor Google está habilitado no Firebase Authentication e que as regras do Firestore permitem apenas as operações autorizadas. A autenticação e as regras de segurança foram mantidas.

## Bug 01 — Leitura do identificador do responsável
- **Arquivo:** `lib/models/ocorrencia.dart`
- **Sintoma:** o identificador do autor era carregado a partir do campo `autorNome`.
- **Causa:** leitura da chave errada no documento do Firestore.
- **Correção:** `autorId` agora é obtido de `d['autorId']`.
- **Teste:** cadastrar uma ocorrência e conferir se o `autorId` lido corresponde ao UID da conta autenticada.

## Bug 02 — Estado de resolução invertido
- **Arquivo:** `lib/models/ocorrencia.dart`
- **Sintoma:** ocorrências abertas podiam ser exibidas como resolvidas e vice-versa.
- **Causa:** o valor booleano armazenado era negado durante a conversão do documento.
- **Correção:** leitura direta de `d['resolvido']`, mantendo `false` como padrão.
- **Teste:** conferir um registro com `resolvido: false` e outro com `resolvido: true`.

## Bug 03 — Validação incompleta do cadastro
- **Arquivo:** `lib/pages/central_page.dart`
- **Sintoma:** o formulário aceitava cadastro quando apenas um dos campos obrigatórios estava preenchido.
- **Causa:** a condição usava `&&` em vez de `||`.
- **Correção:** impedir o cadastro quando título **ou** local estiver vazio.
- **Teste:** tentar enviar o formulário com título vazio e, separadamente, com local vazio; ambos devem ser recusados.

## Bug 04 — Fechamento da tela errada após cadastrar
- **Arquivo:** `lib/pages/central_page.dart`
- **Sintoma:** após registrar uma ocorrência, a navegação podia fechar a tela principal em vez do diálogo.
- **Causa:** o método usava o `context` da página para executar o `pop`.
- **Correção:** `cadastrar` recebe o `dialogContext` e fecha especificamente o diálogo.
- **Teste:** registrar uma ocorrência e confirmar que o formulário fecha, mas a lista principal permanece aberta.

## Bug 05 — Valor do filtro não era atualizado corretamente
- **Arquivo:** `lib/pages/central_page.dart`
- **Sintoma:** o controle do filtro podia assumir um valor diferente daquele selecionado.
- **Causa:** o callback invertia o valor recebido usando `!value`.
- **Correção:** atribuir diretamente `somenteAbertos = value`.
- **Teste:** ligar e desligar o filtro e verificar se o controle acompanha cada seleção.

## Bug 06 — Filtro de ocorrências abertas invertido
- **Arquivo:** `lib/pages/central_page.dart`
- **Sintoma:** o filtro “Somente não resolvidos” mostrava ocorrências resolvidas.
- **Causa:** a consulta filtrava `resolvido == true`.
- **Correção:** filtrar por `!o.resolvido`.
- **Teste:** manter uma ocorrência aberta e outra resolvida; com o filtro ligado, somente a aberta deve aparecer.

## Bug 07 — Detalhe aberto sem a ocorrência selecionada
- **Arquivo:** `lib/pages/central_page.dart`
- **Sintoma:** a tela de detalhes era chamada sem receber o registro selecionado, embora seu construtor exigisse esse objeto.
- **Causa:** a navegação criava `DetalhePage()` sem o argumento obrigatório.
- **Correção:** passar `ocorrencia: o` para a página de detalhes.
- **Teste:** abrir duas ocorrências diferentes e conferir se cada detalhe apresenta os dados correspondentes.

## Bug 08 — Validação da pista invertida
- **Arquivo:** `lib/pages/detalhe_page.dart`
- **Sintoma:** o envio era interrompido quando havia texto e prosseguia quando o campo estava vazio.
- **Causa:** a condição de validação estava invertida.
- **Correção:** bloquear o envio quando `pista.text.trim().isEmpty` e informar o usuário.
- **Teste:** tentar enviar uma pista vazia e confirmar que ela não é gravada.

## Bug 09 — Texto da pista não era enviado
- **Arquivo:** `lib/pages/detalhe_page.dart`
- **Sintoma:** a chamada do serviço enviava uma string vazia, descartando o conteúdo digitado.
- **Causa:** argumento literal vazio em `enviarPista`.
- **Correção:** enviar `pista.text`; o serviço aplica `trim()` antes de gravar.
- **Teste:** enviar uma pista com texto e conferir o conteúdo exibido na lista de pistas.

## Bug 10 — UID do responsável gravado incorretamente
- **Arquivo:** `lib/services/central_service.dart`
- **Sintoma:** o campo `autorId` armazenava o e-mail, mas a autorização compara o UID.
- **Causa:** uso de `u.email` no lugar de `u.uid`.
- **Correção:** gravar `u.uid` em `autorId`.
- **Teste:** criar uma ocorrência em uma conta e verificar se o UID gravado coincide com `currentUser.uid`.

## Bug 11 — Status não alternava ao atualizar
- **Arquivo:** `lib/services/central_service.dart`
- **Sintoma:** a ação de marcar como resolvido ou reabrir gravava o mesmo status que já estava no objeto.
- **Causa:** o serviço atualizava `item.resolvido` sem inverter o estado.
- **Correção:** gravar `!item.resolvido`. A verificação de propriedade pelo UID foi preservada.
- **Teste:** como autor, alternar entre resolvido e em aberto; em outra conta, tentar alterar e confirmar que a operação é recusada.

## Bug 12 — Pistas gravadas na ocorrência errada
- **Arquivo:** `lib/services/central_service.dart`
- **Sintoma:** pistas eram gravadas sempre no documento de ID literal `pistas`, em vez de ficarem vinculadas ao registro aberto.
- **Causa:** uso de `.doc('pistas')` ignorando o parâmetro `ocorrenciaId`.
- **Correção:** gravar em `.doc(ocorrenciaId).collection('pistas')`.
- **Teste:** enviar pistas em duas ocorrências distintas e confirmar que cada uma aparece somente no detalhe correspondente.

## Verificações finais

Os testes acima descrevem os procedimentos para validar cada correção. Eles precisam ser executados no ambiente Flutter/Firebase da escola, com duas contas Google de teste. Não foi possível confirmar execução integrada neste ambiente porque o ZIP não inclui `lib/firebase_options.dart` nem as credenciais/configuração do projeto Firebase.

Checklist de validação:
- [ ] `flutter pub get`
- [ ] Gerar `lib/firebase_options.dart` com a configuração Firebase da escola.
- [ ] `flutter analyze`
- [ ] Executar no Chrome e testar cadastro, filtro, detalhes, status e pistas.
- [ ] Entrar com duas contas Google diferentes e confirmar a atualização em tempo real.
- [ ] Registrar captura de tela das duas contas visualizando a mesma ocorrência.
